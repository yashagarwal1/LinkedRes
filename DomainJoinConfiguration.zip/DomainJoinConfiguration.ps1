Configuration DomainJoinConfiguration
{   
	Install-Module -Name xDSCDomainjoin -Force
	Import-DscResource -ModuleName 'PSDesiredStateConfiguration'
        Import-DscResource -ModuleName 'xDSCDomainjoin'

   
    #domain credentials to be given here   
    $secdomainpasswd = ConvertTo-SecureString "testadmin@1234" -AsPlainText -Force
    $mydomaincreds = New-Object System.Management.Automation.PSCredential ("testyash@testyashdom.local", $secdomainpasswd)
   
        
    node $AllNodes.NodeName   
    {
        xDSCDomainjoin JoinDomain
        {
            Domain = 'testyashdom.local'
            Credential = $mydomaincreds
           
        }
    }
}