Configuration DomainJnConfiguration
{   
Import-DscResource -ModuleName xComputerManagement
$DomainName = 'testyashdom.local'
$secdomainpasswd = ConvertTo-SecureString "testadmin@1234" -AsPlainText -Force
 $mydomaincreds = New-Object System.Management.Automation.PSCredential ("testyash@testyashdom.local", $secdomainpasswd)

 Node localhost
    {
 xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $mydomaincreds 	
        }
}
}